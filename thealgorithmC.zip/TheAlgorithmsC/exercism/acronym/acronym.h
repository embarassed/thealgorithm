#ifndef ACRONYM_H
#define ACRONYM_H

char *abbreviate(const char *phrase);

#endif
